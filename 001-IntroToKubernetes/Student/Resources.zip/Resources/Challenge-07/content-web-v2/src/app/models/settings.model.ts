export class Settings {
    contentUrl: string;
}
